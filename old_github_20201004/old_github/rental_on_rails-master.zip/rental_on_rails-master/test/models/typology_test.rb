require 'test_helper'

class TypologyTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
