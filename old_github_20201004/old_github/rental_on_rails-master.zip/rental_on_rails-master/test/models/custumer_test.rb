require 'test_helper'

class CustumerTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
