class Custumer < ActiveRecord::Base
	belongs_to :order
end
