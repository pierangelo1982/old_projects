class Typology < ActiveRecord::Base
	has_many :products
end
