class Delivery < ActiveRecord::Base
end
