module TypologiesHelper
end
