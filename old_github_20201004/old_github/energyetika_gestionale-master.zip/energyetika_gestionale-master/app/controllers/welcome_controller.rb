class WelcomeController < ApplicationController
  def index
  end

  def test
  end
end
