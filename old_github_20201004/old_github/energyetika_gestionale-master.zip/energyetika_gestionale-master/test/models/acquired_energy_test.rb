require 'test_helper'

class AcquiredEnergyTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
