require 'test_helper'

class ThermalEnergyProductionItemTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
