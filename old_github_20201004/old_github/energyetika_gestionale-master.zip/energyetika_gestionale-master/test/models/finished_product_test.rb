require 'test_helper'

class FinishedProductTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
