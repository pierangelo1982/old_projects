require 'test_helper'

class ThermalProductionTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
