require 'test_helper'

class CompanyContactPersonTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
