require 'test_helper'

class UtilityTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
