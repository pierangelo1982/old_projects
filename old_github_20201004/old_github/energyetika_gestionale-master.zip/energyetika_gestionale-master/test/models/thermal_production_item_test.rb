require 'test_helper'

class ThermalProductionItemTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
