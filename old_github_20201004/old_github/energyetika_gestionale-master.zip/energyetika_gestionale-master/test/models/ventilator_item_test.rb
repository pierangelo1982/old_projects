require 'test_helper'

class VentilatorItemTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
