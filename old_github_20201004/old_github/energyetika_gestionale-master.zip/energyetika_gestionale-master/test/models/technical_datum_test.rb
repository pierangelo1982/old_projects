require 'test_helper'

class TechnicalDatumTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
