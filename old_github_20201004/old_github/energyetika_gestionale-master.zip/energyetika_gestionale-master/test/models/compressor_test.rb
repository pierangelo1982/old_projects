require 'test_helper'

class CompressorTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
