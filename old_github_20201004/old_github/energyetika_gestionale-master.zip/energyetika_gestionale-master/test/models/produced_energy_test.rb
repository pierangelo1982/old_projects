require 'test_helper'

class ProducedEnergyTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
