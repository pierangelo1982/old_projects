require "application_system_test_case"

class FinishedProductsTest < ApplicationSystemTestCase
  # test "visiting the index" do
  #   visit finished_products_url
  #
  #   assert_selector "h1", text: "FinishedProduct"
  # end
end
