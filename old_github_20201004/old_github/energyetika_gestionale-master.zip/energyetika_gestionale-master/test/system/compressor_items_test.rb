require "application_system_test_case"

class CompressorItemsTest < ApplicationSystemTestCase
  # test "visiting the index" do
  #   visit compressor_items_url
  #
  #   assert_selector "h1", text: "CompressorItem"
  # end
end
