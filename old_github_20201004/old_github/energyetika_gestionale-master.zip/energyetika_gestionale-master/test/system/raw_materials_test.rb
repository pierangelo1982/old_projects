require "application_system_test_case"

class RawMaterialsTest < ApplicationSystemTestCase
  # test "visiting the index" do
  #   visit raw_materials_url
  #
  #   assert_selector "h1", text: "RawMaterial"
  # end
end
