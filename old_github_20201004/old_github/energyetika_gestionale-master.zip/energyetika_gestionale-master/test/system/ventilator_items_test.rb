require "application_system_test_case"

class VentilatorItemsTest < ApplicationSystemTestCase
  # test "visiting the index" do
  #   visit ventilator_items_url
  #
  #   assert_selector "h1", text: "VentilatorItem"
  # end
end
