require "application_system_test_case"

class TransformersTest < ApplicationSystemTestCase
  # test "visiting the index" do
  #   visit transformers_url
  #
  #   assert_selector "h1", text: "Transformer"
  # end
end
