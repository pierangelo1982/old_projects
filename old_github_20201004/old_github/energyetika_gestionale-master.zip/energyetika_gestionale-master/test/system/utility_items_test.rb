require "application_system_test_case"

class UtilityItemsTest < ApplicationSystemTestCase
  # test "visiting the index" do
  #   visit utility_items_url
  #
  #   assert_selector "h1", text: "UtilityItem"
  # end
end
