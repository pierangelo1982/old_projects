require "application_system_test_case"

class VentilatorsTest < ApplicationSystemTestCase
  # test "visiting the index" do
  #   visit ventilators_url
  #
  #   assert_selector "h1", text: "Ventilator"
  # end
end
