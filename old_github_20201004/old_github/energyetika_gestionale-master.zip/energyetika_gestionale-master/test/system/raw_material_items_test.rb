require "application_system_test_case"

class RawMaterialItemsTest < ApplicationSystemTestCase
  # test "visiting the index" do
  #   visit raw_material_items_url
  #
  #   assert_selector "h1", text: "RawMaterialItem"
  # end
end
