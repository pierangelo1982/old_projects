require "application_system_test_case"

class ProducedEnergiesTest < ApplicationSystemTestCase
  # test "visiting the index" do
  #   visit produced_energies_url
  #
  #   assert_selector "h1", text: "ProducedEnergy"
  # end
end
