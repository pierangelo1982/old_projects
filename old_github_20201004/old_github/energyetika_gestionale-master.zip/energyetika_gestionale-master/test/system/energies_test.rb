require "application_system_test_case"

class EnergiesTest < ApplicationSystemTestCase
  # test "visiting the index" do
  #   visit energies_url
  #
  #   assert_selector "h1", text: "Energy"
  # end
end
