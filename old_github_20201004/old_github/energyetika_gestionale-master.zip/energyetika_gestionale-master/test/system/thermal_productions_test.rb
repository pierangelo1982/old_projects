require "application_system_test_case"

class ThermalProductionsTest < ApplicationSystemTestCase
  # test "visiting the index" do
  #   visit thermal_productions_url
  #
  #   assert_selector "h1", text: "ThermalProduction"
  # end
end
