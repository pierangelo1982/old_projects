require "application_system_test_case"

class ThermalEnergyProductionItemsTest < ApplicationSystemTestCase
  # test "visiting the index" do
  #   visit thermal_energy_production_items_url
  #
  #   assert_selector "h1", text: "ThermalEnergyProductionItem"
  # end
end
