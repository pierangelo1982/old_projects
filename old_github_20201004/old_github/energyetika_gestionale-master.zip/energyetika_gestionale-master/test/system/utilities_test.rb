require "application_system_test_case"

class UtilitiesTest < ApplicationSystemTestCase
  # test "visiting the index" do
  #   visit utilities_url
  #
  #   assert_selector "h1", text: "Utility"
  # end
end
