require "application_system_test_case"

class WalkingHoursTest < ApplicationSystemTestCase
  # test "visiting the index" do
  #   visit walking_hours_url
  #
  #   assert_selector "h1", text: "WalkingHour"
  # end
end
