require "application_system_test_case"

class AcquiredEnergiesTest < ApplicationSystemTestCase
  # test "visiting the index" do
  #   visit acquired_energies_url
  #
  #   assert_selector "h1", text: "AcquiredEnergy"
  # end
end
