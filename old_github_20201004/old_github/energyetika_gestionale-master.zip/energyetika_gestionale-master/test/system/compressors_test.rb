require "application_system_test_case"

class CompressorsTest < ApplicationSystemTestCase
  # test "visiting the index" do
  #   visit compressors_url
  #
  #   assert_selector "h1", text: "Compressor"
  # end
end
