require "application_system_test_case"

class ThermalProductionItemsTest < ApplicationSystemTestCase
  # test "visiting the index" do
  #   visit thermal_production_items_url
  #
  #   assert_selector "h1", text: "ThermalProductionItem"
  # end
end
