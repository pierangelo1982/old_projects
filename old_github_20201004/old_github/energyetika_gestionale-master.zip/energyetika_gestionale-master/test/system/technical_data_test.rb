require "application_system_test_case"

class TechnicalDataTest < ApplicationSystemTestCase
  # test "visiting the index" do
  #   visit technical_data_url
  #
  #   assert_selector "h1", text: "TechnicalDatum"
  # end
end
