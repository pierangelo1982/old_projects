require "application_system_test_case"

class TransformerItemsTest < ApplicationSystemTestCase
  # test "visiting the index" do
  #   visit transformer_items_url
  #
  #   assert_selector "h1", text: "TransformerItem"
  # end
end
